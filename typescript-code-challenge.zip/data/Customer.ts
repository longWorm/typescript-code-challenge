export default interface Customer {
  id: string;
  name: string;
  address: string;
}
