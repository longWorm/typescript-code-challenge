export default interface Item {
  item: string;
  quantity: number;
  price: number;
  revenue: number;
}
