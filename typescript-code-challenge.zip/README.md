# Sinefa TypeScript Challenge Instructions

To transform `data.json` into `data-transformed.json`, run this command: npm run transform (it builds project into `build` folder and then executes it)
To run unit tests: npm run test
